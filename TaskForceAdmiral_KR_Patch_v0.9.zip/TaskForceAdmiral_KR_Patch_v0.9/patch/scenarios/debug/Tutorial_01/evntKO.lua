t = 0
--init is called every time this level is loaded
function ScenarioEvents:init()
		--self.Lakunai = GameData.get():getFleetByName("Lakunai-Flt"):getAirStrip("Lakunai")
	--self.player1 = GameData.get():getPlayer(1)
	TutorialWidget:focusOnElement("DeckButton")
end
--scenarioLoaded is only called once ! Never when loading a game
function ScenarioEvents:scenarioLoaded()
	TutorialWidget:focusOnElement("")
	--Focus on Atlanta ship
	local fleet = GameData.get():getMainLocalPlayerFleet()
	if(fleet ~=nil) then
		-- todo: make a focus(unit) function
		InGameCamera.objectToTrack = fleet:getAdmiralShip()
		log("tracked ship="..fleet:getAdmiralShip():getName())
		HUD.get():setTrackedObject(InGameCamera.objectToTrack)
		InGameCamera:setState(STATE_ORBIT)
		--for now hard coded for Atlanta class
		--woud be better with camera azimuth
		--and even better full automatic, depending on the ship size and heading
		InGameCamera.mapCamera:setPosition(11.70, 5.88, 15.15)

		--Tutorial overlay focus on the element, taking its position and size
		--Model dialog blocks the game until validation
		--Next step is executed after validation
		-- usage is blockOnFocus(<element_name>, <next_step>, <message>)
		-- todo: localisation
		TutorialWidget:blockOnPopup("tutorial_step_01",
		"Greetings,\nWelcome in **Task Force Admiral** tutorial system.\n\nThis message is blocking and next step will launch as soon as you **close** this window.")
	end
	
end

function ScenarioEvents:tutorial_step_01()
	TutorialWidget:showMessage("Click on the **highlighted button** to enter the **Flagplot**\n\nYou cannot click on anything, but keyboard shortcuts are still active.")--non blocking
	TutorialWidget:blockOnFocus("DeckButton", "tutorial_step_02","")
end

function ScenarioEvents:tutorial_step_02()
	--wait for the view switch (no need if custom dialog box instead of showModalPopupMarkdown)
	local timer = Tweens.Timer(0.5):useUnscaledTime()
	OnTweenEnd(timer,0,"ScenarioEvents:tutorial_step_99()")
end

function ScenarioEvents:tutorial_step_99()
	TutorialWidget:showMessage("Great job! The tutorial's tutorial is now over.\n\nYou can quit the level or continue playing.")
end

function ScenarioEvents:update()
--	local offset = InGameCamera.mapCamera:getPosition()
--	log("offset x="..offset.x.." y="..offset.y.." z="..offset.z)
--	log("yaw="..InGameCamera.OrbitYaw.." pitch="..InGameCamera.OrbitPitch)
end

--function ScenarioEvents:onObjective1Completed(endType)

--	if(entType == SVSC_SUCCESS) then
--	else
--	end
--end

function ScenarioEvents:updateFixed(dt)

	--if(not self.Lakunai:testFlag(0x10000000)) then
	--	local contact = self.player1:hasEnemyContactAtDistFrom(self.Lakunai,520) --nautical miles
	--	if(contact ~= nil and GameData.get():isDayTime(2)) then	--2 hours margin before sunset
	--		local mission = self.Lakunai:getATC():setupStrikeOnPos(contact:getCurrentPosition(), 0, GameData.get():getCurrentTime(), 16, 0, 0)
	--		mission:setLookForNearestFleet(true)
	--		mission:setState(1)
	--		self.Lakunai:setFlag(0x10000000)
	--	end
	--end
end
