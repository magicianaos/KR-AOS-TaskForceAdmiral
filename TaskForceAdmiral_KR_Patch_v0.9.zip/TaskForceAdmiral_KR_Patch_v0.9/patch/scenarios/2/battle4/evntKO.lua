--init is called every time this level is loaded
function ScenarioEvents:init()	
end

--scenarioLoaded is only called once ! Never when loading a game
function ScenarioEvents:scenarioLoaded()
			
	--Ask Kure to launch a strike on the relief force
	local Kure = GameData.get():getFleetById(7):getAdmiralUnit()
	local ReliefForce = GameData.get():getFleetById(8)
	
	local strike = Kure:getATC():setupStrikeOnPos(ReliefForce:getAdmiralUnit():getPosition(),ARM_SPOT_LAUNCH, DateTime("1942-6-14:4:0:0"),16,0,8)
	strike:setState(1)
	
	--setup the initial searches from the fleets
	local InvasionForce = GameData.get():getFleetById(5)
	local search = InvasionForce:getAirBase():getATC():setupSearch(110,15,450,DateTime("1942-6-14:4:45:0"),3,SD_Priority,SPT_Carrier)
	search:setState(1)
	
	local KB2 = GameData.get():getFleetById(3)
	local search = KB2:getAirBase():getATC():setupSearch(50,15,450,DateTime("1942-6-14:4:45:0"),5,SD_Priority,SPT_Carrier)
	search:setState(1)
	
end

function ScenarioEvents:updateFixed(dt)
		
end
