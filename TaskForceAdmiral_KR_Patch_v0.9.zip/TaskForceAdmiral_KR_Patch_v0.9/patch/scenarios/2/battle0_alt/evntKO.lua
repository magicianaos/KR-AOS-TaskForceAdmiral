--init is called every time this level is loaded
function ScenarioEvents:init()

	self.csf = GameData.get():getFleetByName("항모 타격부대")
	self.player1 = GameData.get():getPlayer(1)
	
end
--scenarioLoaded is only called once ! Never when loading a game
function ScenarioEvents:scenarioLoaded()
			
end

function ScenarioEvents:onObjective1Completed(endType)

	if(entType == SVSC_SUCCESS) then
	else
	end
end

function ScenarioEvents:updateFixed(dt)
	
	if(not self.csf:testFlag(0x10000000)) then
		--check if we already have an interdict task
		if(self.csf:hasTaskOfType(FleetTask.FTT_INTERDICT)) then
			self.csf:setFlag(0x10000000)
		else
			local contact = self.player1:hasEnemyContactAtDistFrom(self.csf:getAdmiralUnit(),300) --nautical miles
			if(contact ~= nil) then
				--push a interdict task
				local task = FleetTask.create(FleetTask.FTT_INTERDICT, self.csf)
				task:setPosition(contact:getCurrentPosition())
				task:setRadius(200000) --meters
				self.csf:pushTask(task)
				self.csf:setFlag(0x10000000)
			end
		end
	end
	
end

function ScenarioEvents:setupStrikeOnMidway()

	local midway = GameData.get():getFleetById(0):getAdmiralUnit()

	local csf = self.csf
	local Akagi = csf:getShipByUUID("88e93c65-1757-4bbe-b782-e8c08a1893cb")
	local Kaga = csf:getShipByUUID("4541d4fa-36af-4438-bf1a-b724bfe731f8")
	local Hiryu = csf:getShipByUUID("a2a5d9d9-10c6-4b38-a3de-fe6f0bd701e5")
	local Soryu = csf:getShipByUUID("ad686024-66ea-4b91-8ff0-e79c17147294")
	
	local takeoffDate= DateTime("1942-6-4:4:30:0")
	local strike1 = Akagi:getAirboss():setupGroundStrike(midway:getPosition(), ARM_SPOT_LAUNCH, takeoffDate, 18, 0, 9)
	local strike2 = Kaga:getAirboss():setupGroundStrike(midway:getPosition(), ARM_SPOT_LAUNCH, takeoffDate, 18, 0, 9)
	local strike3 = Hiryu:getAirboss():setupGroundStrike(midway:getPosition(), ARM_SPOT_LAUNCH, takeoffDate, 0, 18, 9)
	local strike4 = Soryu:getAirboss():setupGroundStrike(midway:getPosition(), ARM_SPOT_LAUNCH, takeoffDate, 0, 18, 9)
		
	local wave=MissionWave()
	wave:addMission(strike1)
	wave:addMission(strike2)
	wave:addMission(strike3)
	wave:addMission(strike4)
	wave:endAddMission()
	
	wave:synchronizeTakeoffAndGreenlight(takeoffDate)
	
	--setup the searches
	--we put two searches to create a hole in the pattern
	--params are: base angle, angle step, radius (km), date, AC count, shadow type,search priority target
	local search = csf:getAirBase():getATC():setupSearch(60,20,500,DateTime("1942-6-4:4:30:0"),7,SD_Priority,SPT_Carrier)
	search:setState(1)

		
end
