--init is called every time this level is loaded
function ScenarioEvents:init()

	self.Lakunai = GameData.get():getFleetByName("라쿠나이 비행대"):getAirStrip("라쿠나이")
	self.player0 = GameData.get():getPlayer(0)
	self.player1 = GameData.get():getPlayer(1)
	
end
--scenarioLoaded is only called once ! Never when loading a game
function ScenarioEvents:scenarioLoaded()
	GameData.get():addRadioMessage(self.player0,
	60, --delay
	"^c00000FFINTEL UPDATE : CINCPAC warns of likely presence of enemy heavy carrier KAGA operating in Coral Sea area. Enemy TF rushing to your expected area of confrontation. Beware of additional enemy air assets.^")
	
end

function ScenarioEvents:onObjective1Completed(endType)

	if(entType == SVSC_SUCCESS) then
	else
	end
end

function ScenarioEvents:updateFixed(dt)

	if(not self.Lakunai:testFlag(0x10000000)) then
		local contact = self.player1:hasEnemyContactAtDistFrom(self.Lakunai,520) --nautical miles
		if(contact ~= nil and GameData.get():isDayTime(2)) then	--2 hours margin before sunset
			local mission = self.Lakunai:getATC():setupStrikeOnPos(contact:getCurrentPosition(), 0, GameData.get():getCurrentTime(), 16, 0, 0)
			mission:setLookForNearestFleet(true)
			mission:setState(1)
			self.Lakunai:setFlag(0x10000000)
		end
	end
end
