--init is called every time this level is loaded
function ScenarioEvents:init()

	self.Lakunai = GameData.get():getFleetByName("라쿠나이"):getAirStrip("라쿠나이")
	self.player1 = GameData.get():getPlayer(1)
	
end
--scenarioLoaded is only called once ! Never when loading a game
function ScenarioEvents:scenarioLoaded()
	
	local tf17 = GameData.get():getFleetById(0)
	local tig = GameData.get():getFleetByName("툴라기 공략대")
	local yorktown = tf17:getShipByUUID("994e5f8a-7bdc-470f-8b13-2effe0d5d9b6")
	local jakes = GameData.get():getSquadronByName("Jakes-Myoko")
	local daves1 = GameData.get():getSquadronByName("Daves-Aoba")
	local daves2 = GameData.get():getSquadronByName("Daves-Furutaka")
	local petes = GameData.get():getSquadronByName("Rekata-Petes")
	local mavis = GameData.get():getSquadronByName("Mavis")
	local shVF = GameData.get():getSquadronByName("Shokaku VF")
	local vs5 = GameData.get():getSquadronByName("VS-5")
	local vb5 = GameData.get():getSquadronByName("VB-5")
	local vt5 = GameData.get():getSquadronByName("VT-5")
	local vf42 = GameData.get():getSquadronByName("VF-42")
	
	-- Japanese search mission: Myoko Jakes already airborne at scenario start
	--[[
	local search = Mission.create(0)
	search:setSectionSize(1)
	search:addPilots(jakes, 4)
	search:setupSearch(nil, 500000, 45, 15) -- null airbase, automatic resolve
	search:setupSearchInFlight(30 * 60) -- rollback 30 min
	search:setName("SEARCH#101")
	]]
	
	-- Japanese search mission: 3 Mavis from lakunai already airborne
	local search = Mission.create(0)
	search:setSectionSize(1)
	search:addPilots(mavis, 3)
	search:setupSearch(nil, 1200000, 30, 15) -- null airbase, automatic resolve
	search:setupSearchInFlight(120 * 60) -- rollback 120 min
	search:setName("SEARCH#101")
	
	-- Japanese search mission: Daves from Aoba and Furutaka already airborne
	local search = Mission.create(0)
	search:setSectionSize(1)
	search:addPilots(daves1, 3)
	search:addPilots(daves2, 3)
	search:setupSearch(nil, 800000, 15, 7) -- null airbase, automatic resolve
	search:setupSearchInFlight(30 * 60) -- rollback 30 min
	search:setName("SEARCH#101")
	
	-- Japanese CAP from CarDiv5 above Invastion Force
	local cap = Mission.create(0)
	cap:setSectionSize(3)
	cap:addPilots(shVF,6)
	cap:setupLongCAPAroundUnit(tig:getAdmiralShip(),700,350,0,0)
	cap:setupInFlight(nil,tig:getAdmiralShip():getPosition(),Vector3(0,0,0))
	cap:setName("CAP#101")
	
	-- Japanese CAP from CarDiv5 above Invastion Force
	local cap = Mission.create(0)
	cap:setSectionSize(3)
	cap:addPilots(petes,3)
	cap:setupLongCAPAroundUnit(tig:getAdmiralShip(),500,300,0,0)
	cap:setupInFlight(nil,tig:getAdmiralShip():getPosition(),Vector3(0,0,0))
	cap:setName("CAP#101")
	
	-- Yorktown strike already airborne at scenario start
	-- NAVSTK#101: 13 VS-5 SBD (LCDR Burch) + 15 VB-5 SBD (LT Short) + 12 VT-5 TBD (LCDR Taylor)
	local strike = Mission.create(0)
	strike:addPilots(vs5, 13)  -- VS-5: 13 SBD Dauntless, LCDR William O. Burch Jr.
	strike:addPilots(vb5, 15)  -- VB-5: 15 SBD Dauntless, LT Wallace C. Short
	strike:addPilots(vt5, 12)  -- VT-5: 12 TBD Devastator, LCDR Joe Taylor
	strike:addEscortPilots(vf42, 18)  -- VF-42: 18 F4F-3
	strike:setupStrike(yorktown, tig:getAdmiralShip())
	strike:setupStrikeInFlight(30 * 60) -- rollback 30 min
	strike:setName("NAVSTK#101")
end

function ScenarioEvents:onObjective1Completed(endType)

	if(entType == SVSC_SUCCESS) then
	else
	end
end

function ScenarioEvents:updateFixed(dt)

end
