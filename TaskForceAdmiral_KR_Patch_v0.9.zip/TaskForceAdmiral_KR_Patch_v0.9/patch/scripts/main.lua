ScriptManager.getSingleton():doFile("CameraTools.lua")
ScriptManager.getSingleton():doFile("FleetAI.lua")

--GLOBALS
--Main views
STATE_FLAGPLOT = 0
STATE_WORLD = 1
STATE_TACTI = 2
STATE_STRAT = 3
STATE_OUIJA = 4
STATE_FORMATIONS = 5
STATE_FLIGHTMANAGEMENT = 6

--Sub views
STATE_ORBIT = 10
STATE_CHASE = 11
STATE_HOOD = 12
STATE_LWING = 13
STATE_RWING = 14
STATE_BACK = 15
STATE_FLYBY = 16
STATE_FREE = 17

MAP_WORLD_SCALE = 160000

function Damp(a, b, lambda, dt)
    return Quaternion.Slerp(1 - math.exp(-lambda * dt),a ,b,true)
end

function mainUpdate(deltaTime)
	if(camcam~=nil) then
		--camcam:activate()
	
	end
	
	--EditorCamera:roll(30*deltaTime,TS_LOCAL)
	--updateWeatherMap(deltaTime)
end

function setupBindings()
	
	local inputMgr = InputManager.getSingleton()
	inputMgr:addAxisBinding("Roll left/right",1,0,0,false,KC_UNASSIGNED,KC_UNASSIGNED)
	inputMgr:addAxisBinding("Yaw left/right",-1,0,0,false,KC_A,KC_D)
	inputMgr:addAxisBinding("Yaw left trigger",4,0,0,false,KC_UNASSIGNED,KC_UNASSIGNED)
	inputMgr:addAxisBinding("Yaw right trigger",5,0,0,false,KC_UNASSIGNED,KC_UNASSIGNED)
	inputMgr:addAxisBinding("Pitch up/down",0,0,0,false,KC_UNASSIGNED,KC_UNASSIGNED)
	inputMgr:addAxisBinding("Throttle",-1,0,0,false,KC_UNASSIGNED,KC_UNASSIGNED)
	inputMgr:addAxisBinding("View left/right",3,0,0,false,KC_LEFT,KC_RIGHT)
	inputMgr:addAxisBinding("View up/down",2,0,0,false,KC_UP,KC_DOWN)
	inputMgr:addCustomValue("Zoom speed",1.0)
	inputMgr:addCustomValue("Mouse sensitivity",1.0)
	inputMgr:addCustomValue("Inverse mouse pitch",0)
	inputMgr:addButtonBinding("Pause",KC_P,-1,-1,-1,0,0.25)
	inputMgr:addButtonBinding("IncrementSpeed",KC_EQUALS,-1,-1,-1,0,0.25)
	inputMgr:addButtonBinding("DecrementSpeed",KC_MINUS,-1,-1,-1,0,0.25)
	inputMgr:addButtonBinding("Increase throttle",KC_W,11,-1,-1,0,0)
	inputMgr:addButtonBinding("Decrease throttle",KC_S,9,-1,-1,0,0)
	inputMgr:addButtonBinding("Fire",KC_UNASSIGNED,8,-1,-1,0,0)
	inputMgr:addButtonBinding("Left",KC_A,-1,-1,-1,0,0)
	inputMgr:addButtonBinding("Right",KC_D,-1,-1,-1,0,0)
	inputMgr:addButtonBinding("Forward",KC_W,-1,-1,-1,0,0)
	inputMgr:addButtonBinding("Backward",KC_S,-1,-1,-1,0,0)
	inputMgr:addButtonBinding("Up",KC_R,-1,-1,-1,0,0)
	inputMgr:addButtonBinding("Down",KC_F,-1,-1,-1,0,0)
	inputMgr:addButtonBinding("Padlock",KC_LMENU,2,-1,-1,0,0.25)
	inputMgr:addButtonBinding("Lock",KC_T,3,-1,-1,0,0.5)
	inputMgr:addButtonBinding("Unlock",KC_Y,-1,-1,-1,0,0.5)
	inputMgr:addButtonBinding("POV Left",KC_UNASSIGNED,-1,-1,-1,0,0)
	inputMgr:addButtonBinding("POV Right",KC_UNASSIGNED,-1,-1,-1,0,0)
	inputMgr:addButtonBinding("POV Up",KC_UNASSIGNED,-1,-1,-1,0,0)
	inputMgr:addButtonBinding("POV Down",KC_UNASSIGNED,-1,-1,-1,0,0)
	inputMgr:addButtonBinding("Show inputs",KC_F1,1,-1,-1,0,0)
	inputMgr:addButtonBinding("Pause menu",KC_UNASSIGNED,0,-1,-1,0,0.25)

	--view 
	InputManager.getSingleton():addButtonBinding("Decrease FOV",KC_MULTIPLY,-1,-1,-1,0,0)
	InputManager.getSingleton():addButtonBinding("Increase FOV",KC_DIVIDE,-1,-1,-1,0,0)
	InputManager.getSingleton():addButtonBinding("Toggle head-bobbing",KC_DECIMAL,-1,-1,-1,0,0.25)
	InputManager.getSingleton():addButtonBinding("Toggle orbit",KC_NUMPADENTER,-1,-1,-1,0,0)
	InputManager.getSingleton():addButtonBinding("Toggle freecam",KC_NUMPAD0,-1,-1,-1,0,0)
	InputManager.getSingleton():addButtonBinding("Chase",KC_NUMPAD5,-1,-1,-1,0,0.25)
	InputManager.getSingleton():addButtonBinding("Front/Bridge/Nose",KC_NUMPAD8,-1,-1,-1,0,0)
	InputManager.getSingleton():addButtonBinding("Rear/Gunner",KC_NUMPAD2,-1,-1,-1,0,0)
	InputManager.getSingleton():addButtonBinding("Port Wing/Side",KC_NUMPAD4,-1,-1,-1,0,0)
	InputManager.getSingleton():addButtonBinding("Starboard Wing/Side",KC_NUMPAD6,-1,-1,-1,0,0)
	InputManager.getSingleton():addButtonBinding("Padlock Friend Aircraft",KC_NUMPAD7,-1,-1,-1,0,0)
	InputManager.getSingleton():addButtonBinding("Padlock Enemy Aircraft",KC_NUMPAD9,-1,-1,-1,0,0)
	InputManager.getSingleton():addButtonBinding("Padlock Friend Ship",KC_NUMPAD1,-1,-1,-1,0,0)
	InputManager.getSingleton():addButtonBinding("Padlock Enemy Ship",KC_NUMPAD3,-1,-1,-1,0,0)
	
end
function onOpenProject()

	setupBindings()
	
	GameManager.getSingleton():setDefaultLevelName("MainMenu")
	
	if(GameManager.getSingleton():getIsInEditorMode()) then
	
		EditorApp.get():addExtraAssetAction("gltf", "importAsShip")
		EditorApp.get():addExtraAssetAction("gltf", "importAsAircraft")
		EditorApp.get():addExtraAssetAction("gltf", "importAsMount")
		EditorApp.get():addExtraAssetAction("gltf", "importAsSimple")
		
	end
	
	FleetBrain.registerAction("TriggerSearches")
	FleetBrain.registerAction("TriggerStrikes")
	FleetBrain.registerAction("Withdraw")
	FleetBrain.registerAction("Loiter")
	FleetBrain.registerAction("CloseDistance")
	FleetBrain.registerAction("FollowFleet")
	
	
	setLocaleFont("zh","NotoSansSC-zh", 1.5, false);
	setLocaleFont("ja","NotoSansSC-ja", 1.5, false);
	setLocaleFont("ko","NotoSerifKR-ko", 1.0, false);
	
end

function onLevelLoaded()
	--initWeatherMap()
	if(GameManager.getSingleton():getLevel():getName() == "Tutorial") then
		--MissionLoader.loadScenarioSA("scenarios/debug/Tutorial_01/scenario.jmis")
	end
end

function onLevelInit()

	if(EditorCamera~=nil) then
		EditorCamera:setNearClipDistance(0.1)
		--EditorCamera:setOrientation(Quaternion(1,0,0,0))
	end
	--GameManager.getSingleton():getSceneManager():setShadowFarDistance(12)
	
	if(GameManager.getSingleton():getLevel():getName() == "TestLevel" and enterprise_01 ~=nil) then
		GameData.getSingleton():setLocalPlayerCarrier(enterprise_01)
		AddDebugPlaneOnDeck(enterprise_01)
	end
	
end

function onLevelClosed()
	GameData.clear()
end

function updateCloudAmbientF(timeOfDay)
	return (1.0+0.5*math.abs((timeOfDay-12)/8)) * 0.4
end
function updateCloudSunF(timeOfDay)

	return 2.0*math.min(1.5,(0.9+0.5*math.abs((timeOfDay-12)/8)))
end


function updateFlare(flare,timeStep,total, lastTick)
	local obj = _G[flare];
	local light = _G[flare.."_light"];
	obj:translate(Vector3(0.05,-0.1,0)*timeStep,TS_LOCAL)
	obj:yaw(36*timeStep,TS_LOCAL)
	local pos = obj:getPosition()
	obj:setCustomParameter(0,Vector4(pos.x,pos.y,pos.z,math.random(20,50)))
	
	light:setPower(math.random(20,50))
end

function takeAircraftControl(aircraft)
	HumanController.init()
	InGameCamera:changeTrackedObject(aircraft)
	InGameCamera:setState(STATE_CHASE)
	HumanController.get():takeControl(aircraft)
end