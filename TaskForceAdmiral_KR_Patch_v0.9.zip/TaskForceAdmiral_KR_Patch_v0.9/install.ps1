﻿
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
function Find-Game {
    $c = @()
    foreach ($base in @("${env:ProgramFiles(x86)}\Steam", "$env:ProgramFiles\Steam")) {
        $c += "$base\steamapps\common\Task Force Admiral"
        $vdf = "$base\steamapps\libraryfolders.vdf"
        if (Test-Path $vdf) {
            foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"')) {
                $c += (($m.Groups[1].Value -replace '\\\\', '\') + '\steamapps\common\Task Force Admiral')
            }
        }
    }
    foreach ($p in $c) { if (Test-Path "$p\bin\master\Plankton.dll") { return $p } }
    return $null
}
function Get-Game {
    $g = Find-Game
    if ($g) { Write-Host "게임 폴더: $g"; return $g }
    Write-Host '스팀 폴더에서 Task Force Admiral 을 찾지 못했습니다.'
    $g = (Read-Host '게임 폴더 전체 경로를 붙여넣고 Enter (bin 폴더가 들어 있는 곳)').Trim('"', ' ')
    if (-not (Test-Path "$g\bin\master\Plankton.dll")) { throw "그 폴더에는 bin\master\Plankton.dll 이 없습니다: $g" }
    return $g
}

$orig = @{
    'bin\master\Plankton.dll' = '76911c68afff1722969435ce89c3d2a219401c5baa5cba80f349d37be8285a64'
    'bin\master\CarriersPlugin.dll' = '845df33e215ca81c484fd5fd6cdeb61e833ca151d793a7b94432b89f496cb769'
}
$patched = @{
    'bin\master\Plankton.dll' = 'a70d0fcedb13fd0a0c406bd67857a9f5ba28b1c9db174429158c0a59d67913eb'
    'bin\master\CarriersPlugin.dll' = '37e4e85bdf7b3a1afa282ad6f105fecc4374a2027b707e38810f7f9f9e0bfb50'
}
try {
    $patch = Join-Path $here 'patch'
    if (-not (Test-Path $patch)) { throw 'patch 폴더가 없습니다. zip 을 먼저 풀어 주세요.' }
    $game = Get-Game
    Write-Host ''
    Write-Host '게임을 완전히 종료한 뒤 계속하세요.'
    Read-Host 'Enter 를 누르면 설치합니다' | Out-Null
    # 게임 버전 확인 (원본이거나 이미 이 패치가 설치된 상태여야 함)
    foreach ($k in $orig.Keys) {
        $h = (Get-FileHash "$game\$k" -Algorithm SHA256).Hash.ToLower()
        if ($h -ne $orig[$k] -and $h -ne $patched[$k]) {
            throw "게임 버전이 다릅니다 ($k). 이 패치는 Task Force Admiral 0.5.25 용입니다. 스팀에서 '파일 무결성 검사' 후 다시 시도하세요."
        }
    }
    $bk = "$game\KR-AOS_backup"; New-Item -ItemType Directory -Force $bk | Out-Null
    $addedFile = "$bk\_added.txt"
    $added = @(); if (Test-Path $addedFile) { $added = @(Get-Content $addedFile) }
    $n = 0
    foreach ($f in Get-ChildItem $patch -Recurse -File) {
        $rel = $f.FullName.Substring($patch.Length + 1)
        $dst = Join-Path $game $rel
        if (Test-Path $dst) {
            $b = Join-Path $bk $rel
            if (-not (Test-Path $b)) { New-Item -ItemType Directory -Force (Split-Path $b) | Out-Null; Copy-Item $dst $b }
        } elseif ($added -notcontains $rel) { $added += $rel }
        New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
        Copy-Item $f.FullName $dst -Force; $n++
    }
    $added | Set-Content $addedFile -Encoding UTF8
    Write-Host ''
    Write-Host "설치 완료: 파일 $n 개"
    Write-Host '게임 실행 → 옵션 → 언어(Language) 를 Korean 으로 바꾸고 게임을 다시 시작하세요.'
    Write-Host '원본으로 되돌리려면 원본복구.bat 을 실행하세요.'
} catch {
    Write-Host ''; Write-Host "오류: $($_.Exception.Message)" -ForegroundColor Red
}
