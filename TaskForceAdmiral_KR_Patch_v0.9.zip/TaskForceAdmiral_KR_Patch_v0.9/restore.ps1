﻿
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
function Find-Game {
    $c = @()
    foreach ($base in @("${env:ProgramFiles(x86)}\Steam", "$env:ProgramFiles\Steam")) {
        $c += "$base\steamapps\common\Task Force Admiral"
        $vdf = "$base\steamapps\libraryfolders.vdf"
        if (Test-Path $vdf) {
            foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"')) {
                $c += (($m.Groups[1].Value -replace '\\\\', '\') + '\steamapps\common\Task Force Admiral')
            }
        }
    }
    foreach ($p in $c) { if (Test-Path "$p\bin\master\Plankton.dll") { return $p } }
    return $null
}
function Get-Game {
    $g = Find-Game
    if ($g) { Write-Host "게임 폴더: $g"; return $g }
    Write-Host '스팀 폴더에서 Task Force Admiral 을 찾지 못했습니다.'
    $g = (Read-Host '게임 폴더 전체 경로를 붙여넣고 Enter (bin 폴더가 들어 있는 곳)').Trim('"', ' ')
    if (-not (Test-Path "$g\bin\master\Plankton.dll")) { throw "그 폴더에는 bin\master\Plankton.dll 이 없습니다: $g" }
    return $g
}

try {
    $game = Get-Game
    Write-Host ''
    Write-Host '게임을 완전히 종료한 뒤 계속하세요.'
    Read-Host 'Enter 를 누르면 원본으로 되돌립니다' | Out-Null
    $bk = "$game\KR-AOS_backup"
    if (-not (Test-Path $bk)) { throw '백업 폴더(KR-AOS_backup)가 없습니다. 설치한 적이 없거나 이미 복구했습니다. 스팀 "파일 무결성 검사"로도 원본으로 돌아갑니다.' }
    $n = 0
    foreach ($f in Get-ChildItem $bk -Recurse -File) {
        if ($f.Name -eq '_added.txt') { continue }
        $rel = $f.FullName.Substring($bk.Length + 1)
        Copy-Item $f.FullName (Join-Path $game $rel) -Force; $n++
    }
    $addedFile = "$bk\_added.txt"
    if (Test-Path $addedFile) {
        foreach ($rel in Get-Content $addedFile) { if ($rel) { Remove-Item (Join-Path $game $rel) -Force -ErrorAction SilentlyContinue } }
    }
    # 언어 설정이 ko 로 남아 있으면 원본 게임이 못 읽을 수 있으므로 en 으로
    try {
        $cfg = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games\TaskForceAdmiral\config\options.cfg'
        if (Test-Path $cfg) {
            $t = Get-Content $cfg -Raw
            $t2 = [regex]::Replace($t, '(?m)^(\s*Language\s*=\s*)ko\b', '${1}en')
            if ($t2 -ne $t) { Set-Content $cfg $t2 -NoNewline; Write-Host '언어 설정을 en 으로 되돌렸습니다.' }
        }
    } catch { }
    Remove-Item $bk -Recurse -Force
    Write-Host ''
    Write-Host "원본 복구 완료: 파일 $n 개 복원"
} catch {
    Write-Host ''; Write-Host "오류: $($_.Exception.Message)" -ForegroundColor Red
}
